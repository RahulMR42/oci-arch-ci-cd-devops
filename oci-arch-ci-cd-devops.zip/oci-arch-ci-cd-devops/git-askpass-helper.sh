#!/bin/sh
exec echo "$GIT_USERNAME"
exec echo "$GIT_PASSWORD"
