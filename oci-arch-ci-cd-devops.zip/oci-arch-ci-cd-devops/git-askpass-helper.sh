#!/bin/sh
exec echo "$GIT_PASSWORD"
